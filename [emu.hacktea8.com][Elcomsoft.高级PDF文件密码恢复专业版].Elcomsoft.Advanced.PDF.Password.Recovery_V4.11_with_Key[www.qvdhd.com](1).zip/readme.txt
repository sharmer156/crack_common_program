
= Contents =

  Introduction
  Requirements and limitations
  Contact information
  Registration


= Introduction =

Unlock PDF documents and remove editing, printing and copying restrictions instantly. Open encrypted and password-protected PDF documents quickly and efficiently. The unique, patent-pending Thunder Tables technology guarantees the recovery of 40-bit keys in under a minute! The multi-threaded low-level code is optimized for modern multi-core PCs, ensuring the best performance and the quickest recovery of the most complex passwords. Removing JScript code, form fields and digital signatures is also an option.


= Requirements and limitations =

- Windows 2000, Windows XP, Windows Server 2003, Windows Vista or Windows Server 2008
- about 6 megabytes of free space on hard disk (4 gigabytes for Enterprise version; 4Gb USB flash drive recommended)

The program can process files encrypted in mode 1 with standard encryption handler only. The documents protected with any other encryption handlers (like FileOpen, SASS_INTERNET_STDS from Standards Australia Software Services, or SoftLock's Acrobat Security Plug-Ins) cannot be decrypted.

Please also note that "key search" attack is not applicable to PDF files with 128-bit encryption.


= Contact information =

For Technical Support, please use the following form:

http://www.crackpassword.com/support/support.php 

You can also contact our Customer Service, Sales or Legal Department at:

http://www.elcomsoft.com/company.html

Our Fax numbers:

+1 866 448-2703 (US and Canada, toll-free)
+44 870 831-2983 (UK)
+49 18054820050734 (Germany)

Please write in English language only.

The latest version of APDFPR is always available from our web page at:

http://www.elcomsoft.com/apdfpr.html

Other password recovery products (for ZIP and RAR archives; Microsoft Office; Lotus Organizer, Lotus 1-2-3, Lotus WordPro, Lotus Approach; Corel Paradox, WordPerfect and QuattroPro; ACT! contact management software, Intuit Quicken and QuickBooks, Adobe Acrobat PDF, email clients, instant messengers, Windows 2000/XP/2003/Vista Encrypting File System on NTFS, Windows NT/2000/XP/2003/Vista user passwords, Windows PWL/RAS/dial-up/VPN/shares/asterisked passwords) are available at:

http://www.elcomsoft.com/prs.html


= Registration =

Unregistered (trial) version decrypts only first 10% pages (but at least one page) of the documents, and replaces all other pages with blank (empty) ones; with a brute-force attack, passwords longer than 4 characters cannot be recovered; some dictionary-attack options are disabled; "Use pre-computed hash tables" option is not available.

See "order.txt" for details on purchasing the full version.